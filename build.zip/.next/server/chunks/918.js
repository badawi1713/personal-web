"use strict";
exports.id = 918;
exports.ids = [918];
exports.modules = {

/***/ 2918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "x$": () => (/* reexport */ components_AboutMe),
  "O$": () => (/* reexport */ components_ActiveLink),
  "S3": () => (/* reexport */ components_Author),
  "b4": () => (/* reexport */ components_BlogContent),
  "fL": () => (/* reexport */ components_BlogDetail),
  "r8": () => (/* reexport */ components_Contact),
  "le": () => (/* reexport */ components_ExperienceCard),
  "ZD": () => (/* reexport */ components_FeaturedBlogCard),
  "Gr": () => (/* reexport */ components_FollowCard),
  "$_": () => (/* reexport */ components_Footer),
  "Ar": () => (/* reexport */ components_Layout),
  "GH": () => (/* reexport */ components_ListBlog),
  "YU": () => (/* reexport */ components_ListBlogCard),
  "aN": () => (/* reexport */ components_Loader),
  "wp": () => (/* reexport */ components_Navbar),
  "dW": () => (/* reexport */ components_PortfolioCard),
  "Xu": () => (/* reexport */ components_RecentBlog),
  "SD": () => (/* reexport */ components_RelatedPostCard),
  "mJ": () => (/* reexport */ components_TechnologiesCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/AboutMe/index.jsx



const AboutMe = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex flex-col items-center justify-center w-full dark:bg-slate-800",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container flex-col-reverse md:flex-row flex items-center px-8 pb-8 md:py-20 gap-8",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                    className: "flex flex-1 flex-col gap-8 md:items-start",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                            className: "text-5xl leading-tight md:leading-snug font-bold",
                            children: [
                                "Hi, I am Dzaky,",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                "Front-End Developer"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "md:w-4/6 text-lg",
                            children: "I described myself as a creative, and willing to learn new. As a front-end developer I am very interested in topics about web application development using React.js and UI/UX design."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "https://bit.ly/3fNmrWc",
                            rel: "noreferrer",
                            target: "_blank",
                            className: " bg-red-400 text-center hover:bg-red-500 dark:bg-sky-400 hover:dark:bg-sky-500 text-white py-4 px-8 rounded-lg hover:-translate-y-1 transition ",
                            children: "Download Resume"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-48 h-48 md:w-72 md:h-72 lg:w-80 lg:h-80 bg-red-400 dark:bg-sky-300 relative rounded-full",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-44 w-44 md:w-64 md:h-64 lg:w-72 lg:h-72 bg-white rounded-full absolute top-0 right-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-full w-full rounded-full relative",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: "/images/img-profile.jpg",
                                className: "rounded-full",
                                layout: "fill",
                                alt: "profile-dzaky"
                            })
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const components_AboutMe = (AboutMe);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/ActiveLink/index.jsx





const ActiveLink = ({ children , activeClassName , ...props })=>{
    const { asPath  } = (0,router_.useRouter)();
    const child = external_react_.Children.only(children);
    const childClassName = child.props.className || "";
    const className = asPath === props.href || asPath === props.as ? `${childClassName} ${activeClassName}`.trim() : childClassName;
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        ...props,
        children: /*#__PURE__*/ external_react_default().cloneElement(child, {
            className: className || null
        })
    }));
};
ActiveLink.propTypes = {
    activeClassName: (external_prop_types_default()).string.isRequired,
    children: (external_prop_types_default()).node
};
/* harmony default export */ const components_ActiveLink = (ActiveLink);

;// CONCATENATED MODULE: ./components/Author/index.jsx



const Author = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex items-center gap-2 mt-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                alt: "author-image",
                width: 64,
                height: 64,
                className: "rounded-full",
                src: "/images/img-profile.jpg"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-base",
                children: [
                    "Written by ",
                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                        className: "text-red-400 dark:text-sky-400",
                        children: "Dzaky Badawi"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_Author = (Author);

;// CONCATENATED MODULE: ./components/BlogContent/index.jsx



const BlogContent = (index1, text, obj, type)=>{
    let modifiedText = text;
    if (obj) {
        if (obj.bold) {
            modifiedText = /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: text
            }, index1);
        }
        if (obj.italic) {
            modifiedText = /*#__PURE__*/ jsx_runtime_.jsx("em", {
                children: text
            }, index1);
        }
        if (obj.underline) {
            modifiedText = /*#__PURE__*/ jsx_runtime_.jsx("u", {
                children: text
            }, index1);
        }
        if (obj.code) {
            modifiedText = /*#__PURE__*/ jsx_runtime_.jsx("pre", {
                className: " overflow-x-auto py-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("code", {
                    className: "rounded-md dark:bg-slate-900 bg-red-300 px-2 py-2",
                    children: text
                })
            });
        }
    }
    switch(type){
        case "heading-three":
            return(/*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-xl font-semibold mb-4",
                children: modifiedText.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                        children: item
                    }, i)
                )
            }, index1));
        case "paragraph":
            return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                children: modifiedText.map((item, i)=>item.type === "pre" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-4",
                        children: item
                    }, i) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "mb-4",
                        children: item
                    }, i)
                )
            }, index1));
        case "heading-four":
            return(/*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "text-md font-semibold mb-4",
                children: modifiedText.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                        children: item
                    }, i)
                )
            }, index1));
        case "image":
            return(/*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                alt: obj.title,
                height: obj.height,
                width: obj.width,
                src: obj.src
            }, index1));
        case "bulleted-list":
            return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "list-disc",
                children: obj?.children?.map((item1)=>item1.children?.map((item2)=>item2.children.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: item.text
                            }, index)
                        )
                    )
                )
            }, index1));
        case "numbered-list":
            return(/*#__PURE__*/ jsx_runtime_.jsx("ol", {
                className: "list-decimal",
                children: obj?.children?.map((item3)=>item3.children?.map((item4)=>item4.children.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: item.text
                            }, index)
                        )
                    )
                )
            }, index1));
        default:
            return modifiedText;
    }
};
/* harmony default export */ const components_BlogContent = (BlogContent);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
;// CONCATENATED MODULE: ./components/BlogDetail/index.jsx






const BlogDetail = ({ post  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "p-8 dark:bg-slate-800 flex flex-col gap-8 min-h-screen",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-52 md:h-96 relative border dark:border-slate-600 rounded-md",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: post?.featuredImage?.url || "/images/img-default.jpg",
                                    alt: "illustration",
                                    layout: "fill",
                                    quality: 100,
                                    objectFit: "cover",
                                    className: "aspect-video h-full bg-cover rounded-md w-full",
                                    loading: "lazy"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "text-4xl font-bold",
                                        children: post?.title
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center gap-2 mt-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoCalendar, {
                                                className: "text-red-400 dark:text-sky-400"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: external_moment_default()(post?.createdAt || new Date()).format("MMMM DD, YYYY")
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("article", {
                                className: "p-8 dark:bg-slate-700 rounded-md shadow-md",
                                children: post?.content?.raw?.children?.map((typeObj, index)=>{
                                    const children = typeObj.children.map((item, itemIndex)=>{
                                        return components_BlogContent(itemIndex, item.text, item);
                                    });
                                    return components_BlogContent(index, children, typeObj, typeObj.type);
                                }) || /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "No content here"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Author, {})
                        ]
                    }),
                    post?.categories?.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("header", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "text-xl font-bold",
                                            children: "Related Posts"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(components_RelatedPostCard, {
                                        slug: post?.slug,
                                        categories: post?.categories?.map((category)=>category.slug
                                        )
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    }));
};
/* harmony default export */ const components_BlogDetail = (BlogDetail);

;// CONCATENATED MODULE: ./components/Contact/index.jsx



const Contact = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container px-8",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-xl mb-4 font-bold",
                children: "Feel free to contact me"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-4 items-start",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        rel: "noreferrer",
                        target: "_blank",
                        href: "https://wa.me/6282136526483",
                        className: "flex items-center gap-2 hover:text-red-400 hover:dark:text-sky-400 cursor-pointer",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoWhatsapp, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "+62 821 3652 6483"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        rel: "noreferrer",
                        target: "_blank",
                        href: "https://www.linkedin.com/in/dzaky-badawi-46656a163/",
                        className: "flex items-center gap-2 hover:text-red-400 hover:dark:text-sky-400 cursor-pointer",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoLinkedin, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "linkedin.com/in/dzaky-badawi-46656a163/"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        rel: "noreferrer",
                        href: "mailto: dzaky.badawi@gmail.com",
                        className: "flex items-center gap-2 hover:text-red-400 hover:dark:text-sky-400 cursor-pointer",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoMail, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "dzaky.badawi@gmail.com"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_Contact = (Contact);

;// CONCATENATED MODULE: ./components/ExperienceCard/index.jsx



const ExperienceCard = ({ experience  })=>{
    const { title , experienceTitle , subExperienceTitle , years , company , city , description  } = experience;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-xl text-white font-bold",
                children: title || "Section Title"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shadow-md dark:bg-slate-800 p-8 rounded-md bg-white flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "text-xl font-bold text-red-400 dark:text-sky-400",
                        children: [
                            experienceTitle || "Title",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " (",
                            subExperienceTitle || "Sub Title",
                            ") "
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "font-semibold text-base flex flex-col-reverse md:flex-row md:items-center gap-2 md:gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: years || "Year Active"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "hidden md:block text-xl",
                                children: "|"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    company || "Company Name",
                                    ", ",
                                    city || "City"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base",
                        children: description || "Experience description"
                    })
                ]
            })
        ]
    }));
};
ExperienceCard.propTypes = {
    experience: (external_prop_types_default()).object.isRequired
};
/* harmony default export */ const components_ExperienceCard = (ExperienceCard);

;// CONCATENATED MODULE: ./components/FeaturedBlogCard/index.jsx





const FeaturedBlogCard = ({ post  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white dark:bg-slate-700 border dark:border-slate-600 rounded-md shadow-md flex flex-col-reverse md:flex-row justify-between md:gap-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "py-8 px-4 flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `/blog/post/${post?.slug}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "cursor-pointer hover:text-red-500 hover:dark:text-sky-500 text-2xl font-semibold text-red-400 dark:text-sky-400",
                            children: post?.title
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base leading-5",
                        children: post?.excerpt
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " w-full md:w-96 h-52 md:h-full relative ",
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    alt: "illustration",
                    src: post?.featuredImage?.url || "/images/img-default.jpg",
                    layout: "fill",
                    objectFit: "cover",
                    className: "aspect-video md:bg-cover md:rounded-l-none rounded-t-md md:rounded-r-md"
                })
            })
        ]
    }));
};
FeaturedBlogCard.propTypes = {
    post: (external_prop_types_default()).object
};
/* harmony default export */ const components_FeaturedBlogCard = (FeaturedBlogCard);

;// CONCATENATED MODULE: ./components/FollowCard/index.jsx




const FollowCard = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "sticky md:top-0 px-4 w-full py-8 self-start bg-white dark:bg-slate-700 rounded-md shadow-md flex flex-col gap-8",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-2xl font-semibold",
                children: "follow me"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-3 gap-4 justify-center content-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "https://codepen.io/badawi1713",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            rel: "noreferrer",
                            target: "_blank",
                            className: "cursor-pointer text-red-400 dark:text-sky-400 hover:text-red-500 hover:dark:text-sky-500 text-4xl lg:text-5xl mx-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoCodepen, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "https://www.instagram.com/telur_ramen",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            rel: "noreferrer",
                            target: "_blank",
                            className: "cursor-pointer text-red-400 dark:text-sky-400 hover:text-red-500 hover:dark:text-sky-500 text-4xl lg:text-5xl mx-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoInstagram, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "https://twitter.com/TelurRamen",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            rel: "noreferrer",
                            target: "_blank",
                            className: "cursor-pointer text-red-400 dark:text-sky-400 hover:text-red-500 hover:dark:text-sky-500 text-4xl lg:text-5xl mx-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoTwitter, {})
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_FollowCard = (FollowCard);

;// CONCATENATED MODULE: ./components/Footer/index.jsx



const Footer = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "p-8 flex justify-center dark:bg-slate-800",
        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
            href: "/",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                children: [
                    "\xa9",
                    new Date().getFullYear(),
                    " - ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-red-400 dark:text-sky-400",
                        children: "Dzaky Badawi"
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./components/Layout/index.jsx





const Layout = ({ title , children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Hello, I'm Dzaky Badawi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Navbar, {}),
            children
        ]
    }));
};
Layout.defaultProps = {
    title: "Blog"
};
Layout.propTypes = {
    title: (external_prop_types_default()).string.isRequired,
    children: (external_prop_types_default()).node.isRequired
};
/* harmony default export */ const components_Layout = (Layout);

// EXTERNAL MODULE: external "react-masonry-css"
var external_react_masonry_css_ = __webpack_require__(7125);
var external_react_masonry_css_default = /*#__PURE__*/__webpack_require__.n(external_react_masonry_css_);
;// CONCATENATED MODULE: ./components/ListBlog/index.jsx




const breakpointColumnsObject = {
    default: 2,
    1100: 2,
    700: 1,
    500: 1
};
const ListBlog = ({ children  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_masonry_css_default()), {
        breakpointCols: breakpointColumnsObject,
        className: "my-masonry-grid flex w-full gap-8 ",
        columnClassName: "my-masonry-grid_column flex flex-col gap-8",
        children: children
    }));
};
ListBlog.propTypes = {
    children: (external_prop_types_default()).node.isRequired
};
/* harmony default export */ const components_ListBlog = (ListBlog);

;// CONCATENATED MODULE: ./components/ListBlogCard/index.jsx







const ListBlogCard = ({ post  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white dark:bg-slate-700 rounded-md shadow-md flex flex-col border dark:border-slate-600",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative h-52 w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    src: post?.featuredImage?.url || "/images/img-default.jpg",
                    alt: "illustration",
                    layout: "fill",
                    objectFit: "cover",
                    className: "aspect-video rounded-t-md w-full"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "pt-4 pb-8 px-4 flex flex-col justify-between flex-1 gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-2 justify-end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoCalendar, {
                                className: "text-red-400 dark:text-sky-400"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: external_moment_default()(post?.createdAt || new Date()).format("MMMM DD, YYYY")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: `/blog/post/${post?.slug}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "cursor-pointer hover:text-red-500 hover:dark:text-sky-500 text-2xl font-semibold text-red-400 dark:text-sky-400",
                                    children: post?.title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-base leading-5",
                                children: post?.excerpt
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
ListBlogCard.propTypes = {
    post: (external_prop_types_default()).object
};
/* harmony default export */ const components_ListBlogCard = (ListBlogCard);

;// CONCATENATED MODULE: ./components/Loader/index.jsx


const Loader = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: " flex min-h-screen dark:bg-slate-800 flex-col justify-center items-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            style: {
                margin: "auto",
                display: "block",
                shapeRendering: "auto"
            },
            width: 200,
            height: 200,
            viewBox: "0 0 100 100",
            preserveAspectRatio: "xMidYMid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                    cx: 50,
                    cy: 50,
                    r: 0,
                    fill: "none",
                    stroke: "#e90c59",
                    strokeWidth: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                            attributeName: "r",
                            repeatCount: "indefinite",
                            dur: "1s",
                            values: "0;40",
                            keyTimes: "0;1",
                            keySplines: "0 0.2 0.8 1",
                            calcMode: "spline",
                            begin: "0s"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                            attributeName: "opacity",
                            repeatCount: "indefinite",
                            dur: "1s",
                            values: "1;0",
                            keyTimes: "0;1",
                            keySplines: "0.2 0 0.8 1",
                            calcMode: "spline",
                            begin: "0s"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("circle", {
                    cx: 50,
                    cy: 50,
                    r: 0,
                    fill: "none",
                    stroke: "#46dff0",
                    strokeWidth: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                            attributeName: "r",
                            repeatCount: "indefinite",
                            dur: "1s",
                            values: "0;40",
                            keyTimes: "0;1",
                            keySplines: "0 0.2 0.8 1",
                            calcMode: "spline",
                            begin: "-0.5s"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                            attributeName: "opacity",
                            repeatCount: "indefinite",
                            dur: "1s",
                            values: "1;0",
                            keyTimes: "0;1",
                            keySplines: "0.2 0 0.8 1",
                            calcMode: "spline",
                            begin: "-0.5s"
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Loader = (Loader);

// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
// EXTERNAL MODULE: external "react-switch"
var external_react_switch_ = __webpack_require__(8248);
var external_react_switch_default = /*#__PURE__*/__webpack_require__.n(external_react_switch_);
;// CONCATENATED MODULE: ./components/Navbar/index.jsx







const Navbar = ()=>{
    const { theme , setTheme  } = (0,external_next_themes_.useTheme)();
    const { 0: checked , 1: setChecked  } = (0,external_react_.useState)(false);
    const { 0: mounted , 1: setMounted  } = (0,external_react_.useState)(false);
    const { 0: openSidebar , 1: setOpenSidebar  } = (0,external_react_.useState)(false);
    const { asPath  } = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        const onResize = ()=>{
            window.innerWidth >= 768 && setOpenSidebar(false);
        };
        window.addEventListener('resize', onResize);
        return ()=>{
            window.removeEventListener('resize', onResize);
        };
    }, []);
    (0,external_react_.useEffect)(()=>setMounted(true)
    , []);
    (0,external_react_.useEffect)(()=>{
        const currentTheme = window.localStorage.getItem('theme');
        if (!currentTheme) {
            setChecked(true);
            setTheme('light');
        }
        if (theme === 'dark') {
            setChecked(false);
        } else {
            setChecked(true);
        }
    }, [
        theme,
        setTheme
    ]);
    if (!mounted) return null;
    return openSidebar ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "md:hidden w-full h-full fixed z-30 top-0 left-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed z-40 bg-black h-full w-full opacity-40"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "z-50 fixed w-full shadow-lg flex flex-col bg-white dark:bg-slate-800 p-8 gap-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_switch_default()), {
                                "aria-label": "toggle-theme",
                                offColor: "#7dd3fc",
                                onColor: "#f87171",
                                checked: checked,
                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoSunny, {
                                    className: "text-xl h-full flex items-center justify-center ml-1 text-white"
                                }),
                                uncheckedIcon: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoMoon, {
                                    className: "text-xl h-full flex items-center justify-center ml-1 text-white"
                                }),
                                onChange: ()=>{
                                    setTheme(theme === 'dark' ? 'light' : 'dark');
                                    setChecked(!checked);
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                "aria-label": "nav-menu-close",
                                onClick: ()=>setOpenSidebar(false)
                                ,
                                className: "h-8 w-8 rounded-md text-xl shadow-md flex justify-center items-center border border-red-400 dark:border-sky-300",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoClose, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                        className: "md:hidden flex-col flex gap-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                                activeClassName: 'text-red-400 dark:text-sky-400',
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>setOpenSidebar(false)
                                    ,
                                    className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                                activeClassName: 'text-red-400 dark:text-sky-400',
                                href: "/blog",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>setOpenSidebar(false)
                                    ,
                                    className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                    children: "Blog"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                                activeClassName: 'text-red-400 dark:text-sky-400',
                                href: "/portfolio",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>setOpenSidebar(false)
                                    ,
                                    className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                    children: "Portfolio"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }) : /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: `w-full ${asPath !== '/' ? ' dark:bg-slate-800 ' : 'absolute top-0'}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " p-8 gap-8 flex justify-between items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((external_react_switch_default()), {
                    "aria-label": "toggle-theme",
                    offColor: "#7dd3fc",
                    onColor: "#f87171",
                    checked: checked,
                    checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoSunny, {
                        className: "text-xl h-full flex items-center justify-center ml-1 text-white"
                    }),
                    uncheckedIcon: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoMoon, {
                        className: "text-xl h-full flex items-center justify-center ml-1 text-white"
                    }),
                    onChange: ()=>{
                        setTheme(theme === 'dark' ? 'light' : 'dark');
                        setChecked(!checked);
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "block md:hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        "aria-label": "nav-menu",
                        onClick: ()=>setOpenSidebar(true)
                        ,
                        className: "h-8 w-8 rounded-md text-xl shadow-md flex justify-center items-center border border-red-400 dark:border-sky-300",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoMenu, {})
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "hidden md:flex items-center gap-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                            activeClassName: 'text-red-400 dark:text-sky-400',
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                            activeClassName: 'text-red-400 dark:text-sky-400',
                            href: "/blog",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                children: "Blog"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(components_ActiveLink, {
                            activeClassName: 'text-red-400 dark:text-sky-400',
                            href: "/portfolio",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "hover:text-red-400 hover:dark:text-sky-400 font-semibold text-lg",
                                children: "Portfolio"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Navbar = (Navbar);

;// CONCATENATED MODULE: ./components/PortfolioCard/index.jsx




const PortfolioCard = ({ portfolio  })=>{
    const { title , year , description , sourceCodeUrl , demoUrl , imageUrl  } = portfolio;
    const openLinkHandler = (link = "https://google.com")=>{
        window.open(link, "_blank");
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rounded-md shadow-md bg-white dark:bg-slate-700 pb-8 flex flex-col gap-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full relative h-80",
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    priority: true,
                    alt: title || "portfolio-img",
                    src: imageUrl || '/images/img-default.jpg',
                    layout: "fill",
                    objectFit: "cover",
                    className: "rounded-t-md"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-8 flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-xl font-bold text-center",
                        children: title || "Project's Title"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-1 px-10 flex items-center justify-center bg-red-400 dark:bg-sky-400 rounded-full mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-white",
                            children: year || "Year"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base my-4",
                        children: description || "Description"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col md:flex-row gap-4 md:justify-end px-8",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>openLinkHandler(sourceCodeUrl)
                        ,
                        title: sourceCodeUrl ? sourceCodeUrl : "Sorry, source code is unavailable",
                        disabled: !sourceCodeUrl,
                        className: "disabled:cursor-not-allowed disabled:dark:bg-slate-400 disabled:bg-slate-400 bg-red-400 hover:bg-red-500 dark:bg-sky-400 hover:dark:bg-sky-500 py-2 px-4 rounded-lg hover:-translate-y-1 transition text-white ",
                        children: "Source Code"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>openLinkHandler(demoUrl)
                        ,
                        title: demoUrl ? demoUrl : "Sorry, demo is unavailable",
                        disabled: !demoUrl,
                        className: "disabled:border-slate-400 disabled:dark:border-slate-400 disabled:text-slate-400 disabled:cursor-not-allowed border border-red-400 hover:border-red-500 dark:border-sky-400 hover:dark:border-sky-500 py-2 px-4 rounded-lg hover:-translate-y-1 transition",
                        children: "View Demo"
                    })
                ]
            })
        ]
    }));
};
PortfolioCard.propTypes = {
    portfolio: (external_prop_types_default()).object
};
/* harmony default export */ const components_PortfolioCard = (PortfolioCard);

;// CONCATENATED MODULE: ./components/RecentBlog/index.jsx




const RecentBlog = ({ posts  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "px-4 w-full py-8 self-start bg-white dark:bg-slate-700 rounded-md shadow-md flex flex-col gap-8",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-2xl font-semibold",
                children: "recent posts"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-col gap-4",
                children: posts?.map((post, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-white p-2 w-10 h-10 flex flex-col items-center rounded-full shrink-0 bg-red-400 dark:bg-sky-400",
                                children: index + 1
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: `/blog/post/${post?.slug}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "cursor-pointer w-full hover:text-red-500 hover:dark:text-sky-500 text-base",
                                    children: post?.title
                                })
                            })
                        ]
                    }, index)
                )
            })
        ]
    }));
};
RecentBlog.propTypes = {
    posts: (external_prop_types_default()).array
};
/* harmony default export */ const components_RecentBlog = (RecentBlog);

// EXTERNAL MODULE: ./services/index.js + 1 modules
var services = __webpack_require__(4196);
;// CONCATENATED MODULE: ./components/RelatedPostCard/index.jsx








const RelatedPostCard = ({ slug , categories  })=>{
    const { 0: relatedPosts , 1: setRelatedPosts  } = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        const getRelatedPosts = async ()=>{
            try {
                const response = await (0,services/* getSimilarPosts */.IQ)(categories, slug);
                setRelatedPosts(response);
            } catch (error) {
                console.log(error);
            }
        };
        getRelatedPosts();
    }, [
        slug,
        categories
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "grid md:grid-cols-3 grid-cols-1 gap-8",
        children: relatedPosts?.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white dark:bg-slate-700 rounded-md shadow-md flex flex-col border dark:border-slate-600",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-52 relative",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: item?.featuredImage?.url || "/images/img-default.jpg",
                            alt: "illustration",
                            layout: "fill",
                            objectFit: "cover",
                            className: "aspect-video rounded-t-md w-full"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "py-8 px-4 flex flex-col justify-between flex-1 gap-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: `/blog/post/${item?.slug}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "cursor-pointer hover:text-red-500 hover:dark:text-sky-500 text-2xl font-semibold text-red-400 dark:text-sky-400",
                                            children: item?.title || "Title"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-base leading-5",
                                        children: item?.excerpt || "This content ..."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-2 mt-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoCalendar, {
                                        className: "text-red-400 dark:text-sky-400"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: external_moment_default()(item?.createdAt || new Date()).format("MMMM DD, YYYY")
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }, index)
        )
    }));
};
RelatedPostCard.propTypes = {
    slug: (external_prop_types_default()).string,
    categories: (external_prop_types_default()).array
};
/* harmony default export */ const components_RelatedPostCard = (RelatedPostCard);

;// CONCATENATED MODULE: ./components/TechnologiesCard/index.jsx



const TechnologiesCard = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-xl text-white font-bold",
                children: "Technologies"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shadow-md dark:bg-slate-800 p-8 rounded-md bg-white flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base",
                        children: "I have worked with a range of technologies in the web development and mobile development."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-3 gap-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoReact, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "Front End with React "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience to create web interfaces with React.js and React Native for mobile platform (Android)"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoVue, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "Front End with Vue "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience creating web interfaces with Vue.js and vuex for global state management"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoSass, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "Web Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience with CSS3 and SASS to make vanilla CSS, also have worked with CSS frameworks like Tailwind"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoFigma, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "UI/UX Tools "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience using tools like Figma, for creating high-fidelity design"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoNodejs, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "Back End "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience build web services and REST API with Node.js (Express) and MongoDB (mongoose)"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-6 md:flex md:flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoLogoGithub, {
                                        className: "text-3xl"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-span-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-xl font-bold text-red-400 dark:text-sky-400",
                                                children: "Repo Tools"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-base mt-2",
                                                children: "Experience using git command and Github for code repository management"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_TechnologiesCard = (TechnologiesCard);

;// CONCATENATED MODULE: ./components/index.js






















/***/ }),

/***/ 4196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "zb": () => (/* reexport */ getPostDetails),
  "Jq": () => (/* reexport */ getPosts),
  "no": () => (/* reexport */ getRecentPosts),
  "IQ": () => (/* reexport */ getSimilarPosts)
});

// UNUSED EXPORTS: getCategories, getCategoryPost, getFeaturedPosts

// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
;// CONCATENATED MODULE: ./services/graphcms/index.js

const graphqlAPI = "https://api-ap-northeast-1.graphcms.com/v2/ckvqg1ldr48va01xk7g0r69en/master" || 0;
const getPosts = async ()=>{
    const query = external_graphql_request_.gql`
    query myQuery {
      postsConnection {
        edges {
          node {
            createdAt
            slug
            title
            excerpt
            featuredPost
            featuredImage {
              url
            }
            categories {
              name
              slug
            }
          }
        }
      }
    }
  `;
    const results = await (0,external_graphql_request_.request)(graphqlAPI, query);
    return results.postsConnection.edges;
};
const getPostDetails = async (slug)=>{
    const query = external_graphql_request_.gql`
    query GetPostDetails($slug: String!) {
      post(where: { slug: $slug }) {
        author {
          bio
          name
          id
          photo {
            url
          }
        }
        createdAt
        slug
        title
        excerpt
        featuredImage {
          url
        }
        categories {
          name
          slug
        }
        content {
          raw
        }
      }
    }
  `;
    const results = await (0,external_graphql_request_.request)(graphqlAPI, query, {
        slug
    });
    return results.post;
};
const getRecentPosts = async ()=>{
    const query = external_graphql_request_.gql`
    query GetPostDetails(){
      posts(orderBy: createdAt_DESC
      last: 3
      ){
        title
        createdAt
        slug
      }
    }
  `;
    const result = await (0,external_graphql_request_.request)(graphqlAPI, query);
    return result.posts;
};
const getSimilarPosts = async (categories, slug)=>{
    const query = external_graphql_request_.gql`
    query GetPostDetails($slug: String!, $categories: [String!]) {
      posts(
        where: {
          slug_not: $slug
          AND: { categories_some: { slug_in: $categories } }
        }
        last: 3
      ) {
        title
        featuredImage {
          url
        }
        createdAt
        slug,
        excerpt
      }
    }
  `;
    const result = await (0,external_graphql_request_.request)(graphqlAPI, query, {
        categories,
        slug
    });
    return result.posts;
};
const getCategories = async ()=>{
    const query = gql`
    query GetGategories {
        categories {
          name
          slug
        }
    }
  `;
    const result = await request(graphqlAPI, query);
    return result.categories;
};
const getCategoryPost = async (slug)=>{
    const query = gql`
    query GetCategoryPost($slug: String!) {
      postsConnection(where: {categories_some: {slug: $slug}}) {
        edges {
          cursor
          node {
            author {
              bio
              name
              id
              photo {
                url
              }
            }
            createdAt
            slug
            title
            excerpt
            featuredImage {
              url
            }
            categories {
              name
              slug
            }
          }
        }
      }
    }
  `;
    const result = await request(graphqlAPI, query, {
        slug
    });
    return result.postsConnection.edges;
};
const getFeaturedPosts = async ()=>{
    const query = gql`
    query GetCategoryPost() {
      posts(where: {featuredPost: true}) {
        author {
          name
          photo {
            url
          }
        }
        featuredImage {
          url
        }
        title
        slug
        createdAt
      }
    }   
  `;
    const result = await request(graphqlAPI, query);
    return result.posts;
};

;// CONCATENATED MODULE: ./services/index.js



/***/ })

};
;