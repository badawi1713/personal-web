"use strict";
(() => {
var exports = {};
exports.id = 371;
exports.ids = [371];
exports.modules = {

/***/ 5511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_portfolio),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/index.js + 19 modules
var components = __webpack_require__(2918);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-masonry-css"
var external_react_masonry_css_ = __webpack_require__(7125);
var external_react_masonry_css_default = /*#__PURE__*/__webpack_require__.n(external_react_masonry_css_);
;// CONCATENATED MODULE: ./utils/data/index.js
const experiences = [
    {
        title: "Work Experience",
        experienceTitle: "Web Developer",
        subExperienceTitle: "Front End Developer",
        company: " PT. Sarana Maju Lestari",
        city: "Surabaya",
        years: "2020 - 2022",
        description: "As front-end developer at PT. Sarana Maju Lestari, I managed to contribute for their ongoing projects like built many user interfaces for SOKKET system and Boiler Auto Tuning dashboard using React.js and tools like Redux thunk, FusionChart, Figma, FuseTheme template, and Tailwind.css."
    },
    {
        title: "Education",
        experienceTitle: "Informatics",
        subExperienceTitle: "Bachelor's Degree",
        company: "Islamic University of Indonesia",
        city: "Sleman",
        years: "2015 - 2019",
        description: "I'm majoring in informatics degree at Islamic University of Indonesia for 4 years. My last project is about to build a verification system for digital forensic documents based on Blockchain technology using Node.js. While I’m in university I also applied for teaching as a web programming practicum assistant."
    }, 
];
const portfolio = [
    {
        title: "Koperasi",
        year: "2021",
        description: "My freelance work, that started on February-April 2021. My job is to create user interfaces for Koperasi App (Rumah Kios) with React Native framework (Android), and integrate REST API with backend team",
        sourceCodeUrl: "https://github.com/badawi1713/koperasi",
        demoUrl: "",
        imageUrl: "/images/img-koperasi.jpg"
    },
    {
        title: "Boiler Auto Tuning",
        year: "2021",
        description: "One of projects from my work at PT. Sarana Maju Lestari. Boiler Auto Tuning dashboard is a web application thats used to monitor sootblow and combustion process in 7 power plants, also to show sootblow efficiency value in form of chart",
        sourceCodeUrl: "",
        demoUrl: "",
        imageUrl: "/images/img-bat.jpg"
    },
    {
        title: "SOKKET Tools",
        year: "2020",
        description: "The main project from my work at PT. Sarana Maju Lestari. SOKKET (Sistem Pengoptimuman Ketersediaan, Keandalan, dan Efisiensi Terintegrasi Unit Pembangkitan) is a web application for our client PT. PJB (Pembangkit Jawa Bali) that used to help monitoring process from plant unit, shows reliability and efficiency value, also to manage reports. For this project I contribute in some modules like to create main dashboard at home page, profile setting, boiler efficiency, cost benefit analysis reliability module, and case management module.",
        sourceCodeUrl: "",
        demoUrl: "",
        imageUrl: "/images/img-sokket.jpg"
    },
    {
        title: "I-Rural Landing Page",
        year: "2020",
        description: "Creating landing page of I-RURAL for Telkom's product. This landing page can be registered by customer and ISP to get I-RURAL services. This web application interfaces are created by React and Tailwind.css",
        sourceCodeUrl: "https://github.com/badawi1713/irural",
        demoUrl: "https://irural.vercel.app/",
        imageUrl: "/images/img-irural.jpg"
    }, 
];

;// CONCATENATED MODULE: ./utils/index.js


;// CONCATENATED MODULE: ./pages/portfolio/index.jsx





const breakpointColumnsObject = {
    default: 2,
    1100: 2,
    700: 1,
    500: 1
};
const Portfolio = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(components/* Layout */.Ar, {
        title: "About Me",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components/* AboutMe */.x$, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                        className: "flex flex-col items-center justify-center w-full dark:bg-slate-700 bg-red-400",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "container flex flex-col px-8 py-20 gap-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(components/* TechnologiesCard */.mJ, {}),
                                experiences.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components/* ExperienceCard */.le, {
                                        experience: item
                                    }, index)
                                )
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        className: "flex flex-col items-center justify-center w-full dark:bg-slate-800",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "container px-8 pt-20 pb-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "text-xl mb-4 font-bold",
                                        children: "Featured Works"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_masonry_css_default()), {
                                        breakpointCols: breakpointColumnsObject,
                                        className: "my-masonry-grid flex w-full gap-8 ",
                                        columnClassName: "my-masonry-grid_column flex flex-col gap-8",
                                        children: portfolio.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components/* PortfolioCard */.dW, {
                                                portfolio: item
                                            }, index)
                                        )
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components/* Contact */.r8, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Footer */.$_, {})
        ]
    }));
};
/* harmony default export */ const pages_portfolio = (Portfolio);
async function getServerSideProps() {
    await new Promise((resolve)=>{
        setTimeout(resolve, 1000);
    });
    return {
        props: {}
    };
}


/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 7125:
/***/ ((module) => {

module.exports = require("react-masonry-css");

/***/ }),

/***/ 8248:
/***/ ((module) => {

module.exports = require("react-switch");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,918], () => (__webpack_exec__(5511)));
module.exports = __webpack_exports__;

})();