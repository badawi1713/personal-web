"use strict";
(() => {
var exports = {};
exports.id = 195;
exports.ids = [195];
exports.modules = {

/***/ 5439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ blog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/index.js + 19 modules
var components = __webpack_require__(2918);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./public/svg/svg-hello.svg
/* harmony default export */ const svg_hello = ({"src":"/_next/static/media/svg-hello.4031a9d1.svg","height":425,"width":979});
;// CONCATENATED MODULE: ./public/svg/index.js



// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./services/index.js + 1 modules
var services = __webpack_require__(4196);
;// CONCATENATED MODULE: ./pages/blog/index.jsx






const Blog = ({ posts , recentPosts  })=>{
    const featuredPost = posts.filter((item)=>item?.node?.featuredPost === true
    );
    const allPosts = posts.filter((item)=>item?.node?.featuredPost === false
    );
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(components/* Layout */.Ar, {
        title: "All Posts",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "min-h-screen flex flex-col w-full dark:bg-slate-800",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                        className: "py-10 flex items-center justify-around px-8 bg-red-400 dark:bg-slate-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                        className: "text-5xl font-bold leading-tight md:leading-snug relative mb-4 text-white",
                                        children: [
                                            "Taste of shoyu ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            " ramen ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: " origin-center rotate-12 ml-4 absolute",
                                                children: "🍜"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-lg text-white",
                                        children: "Welcome to my personal blog"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "hidden md:block",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: svg_hello,
                                    alt: "header-illustrator",
                                    width: 700
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                        className: "grid md:grid-cols-6 grid-cols-1 lg:grid-cols-12 gap-10 px-8 my-8",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                                className: "flex flex-col md:col-span-4 lg:col-span-9 gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(components/* FeaturedBlogCard */.ZD, {
                                        post: featuredPost[0]?.node
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(components/* ListBlog */.GH, {
                                        children: allPosts.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components/* ListBlogCard */.YU, {
                                                post: item.node
                                            }, index)
                                        )
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:col-span-2 lg:col-span-3 w-full relative",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "md:sticky md:top-4 w-full flex flex-col gap-4 ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(components/* RecentBlog */.Xu, {
                                            posts: recentPosts
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(components/* FollowCard */.Gr, {})
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Footer */.$_, {})
        ]
    }));
};
/* harmony default export */ const blog = (Blog);
async function getStaticProps() {
    const posts = await (0,services/* getPosts */.Jq)() || [];
    const recentPosts = await (0,services/* getRecentPosts */.no)() || [];
    await new Promise((resolve)=>{
        setTimeout(resolve, 1000);
    });
    return {
        props: {
            posts,
            recentPosts
        }
    };
}


/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 7125:
/***/ ((module) => {

module.exports = require("react-masonry-css");

/***/ }),

/***/ 8248:
/***/ ((module) => {

module.exports = require("react-switch");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,918], () => (__webpack_exec__(5439)));
module.exports = __webpack_exports__;

})();